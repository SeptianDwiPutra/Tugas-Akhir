package septiandp.kamusistilahmusik;

import android.os.CountDownTimer;

public class SplashTimer extends CountDownTimer {
    
}
